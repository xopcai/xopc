import { modelResponseMetadata } from './response-metadata.js';

const MAX_RESPONSE_BYTES = 256 * 1024;

type ReadIssue = 'body_missing' | 'too_large' | 'invalid_json' | 'read_failed';
export type ResponseMetadataRead = { bytes: number; metadata?: ReturnType<typeof modelResponseMetadata>; readIssue?: ReadIssue };

/** The original response remains readable by the production adapter. */
export async function readResponseMetadata(response: Response, maxBytes = MAX_RESPONSE_BYTES): Promise<ResponseMetadataRead> {
  if (!Number.isInteger(maxBytes) || maxBytes < 1 || maxBytes > MAX_RESPONSE_BYTES) throw new RangeError('Invalid metadata byte limit');
  let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
  let bytes = 0;
  try {
    reader = response.clone().body?.getReader();
    if (!reader) return { bytes, readIssue: 'body_missing' };
    const parts: Uint8Array[] = [];
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      bytes += part.value.byteLength;
      if (bytes > maxBytes) {
        // A tee cancellation may wait for the original branch. Do not await it here.
        void reader.cancel().catch(() => {});
        return { bytes, readIssue: 'too_large' };
      }
      parts.push(part.value);
    }
    let payload: unknown;
    try { payload = JSON.parse(Buffer.concat(parts).toString('utf8')); }
    catch { return { bytes, readIssue: 'invalid_json' }; }
    return { bytes, metadata: modelResponseMetadata(payload) };
  } catch {
    if (reader) void reader.cancel().catch(() => {});
    return { bytes, readIssue: 'read_failed' };
  } finally { reader?.releaseLock(); }
}
